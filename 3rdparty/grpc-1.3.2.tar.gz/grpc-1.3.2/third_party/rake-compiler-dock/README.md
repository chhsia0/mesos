This is a modified Dockerfile taken from [rake-compiler-dock](https://github.com/rake-compiler/rake-compiler-dock) for the purpose of building gRPC's ruby gem.
